package NetworkModels;

import java.io.Serializable;

/**
 *
 * @author Mehmed Sefa
 */
public class LoginInformation implements Serializable{
    String username;
    String password;

    public String getUserName() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    
    
    public LoginInformation(String username, String password) {
        this.username = username;
        this.password = password;
    }
    
    
    public boolean isMatched(String username, String password){
        if(this.username.equals(username) && this.password.equals(password))
            return true;
        return false;
    }
    
    public boolean isMatched(LoginInformation li){
        return isMatched(li.username, li.password);
    }
}
