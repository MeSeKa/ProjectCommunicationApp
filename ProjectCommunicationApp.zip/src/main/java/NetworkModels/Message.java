package NetworkModels;

import java.io.Serializable;

/**
 *
 * @author Mehmed Sefa
 */
public class Message implements Serializable{
    MessageType messageType;
    Object content;

    public MessageType getMessageType() {
        return messageType;
    }

    public void setMessageType(MessageType messageType) {
        this.messageType = messageType;
    }

    public Object getContent() {
        return content;
    }

    public void setContent(Object content) {
        this.content = content;
    }

    public Message(MessageType messageType, Object content) {
        this.messageType = messageType;
        this.content = content;
    }
    
}
