package NetworkModels;

import java.io.Serializable;

/**
 *
 * @author Mehmed Sefa
 */
public enum MessageType implements Serializable {
    LoginInformation,
    RegisterInformation,
    CreateProject,
    CreateChatroom,
    CreateFriendShip,
    RequestProjects,
    RequestChatrooms,
    RequestFriendShips,
    JoinProject,
    AddFriendToChatroom,
    CreateMessage,
    SingleChatMessage,
    MessageWithFile,
    Person,
    RequestAllChatroomMessages,
    RequestAllFriendShipMessages,
    Approve,
    Wrong,
}
