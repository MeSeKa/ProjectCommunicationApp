package Models;

/**
 *
 * @author Mehmed Sefa
 */
public class ChatMessageWithFile extends ChatMessage {

    byte[] fileContent;
    String fileName;

    public ChatMessageWithFile(int senderId, int chatroomId, String content, String sendAt, byte[] fileContent, String fileName) {
        super(senderId, chatroomId, content, sendAt);
        this.fileContent = fileContent;
        this.fileName = fileName;
    }

    public byte[] getFileContent() {
        return fileContent;
    }

    public void setFileContent(byte[] fileContent) {
        this.fileContent = fileContent;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    
    

    public static String getExtension(String filename) {
        StringBuilder sb = new StringBuilder();

        boolean isDotFound = false;
        for (int i = 0; i < filename.length(); i++) {
            if (!isDotFound && filename.charAt(i) == '.') {
                isDotFound = true;
                continue;
            }
            if (isDotFound) {
                sb.append(filename.charAt(i));
            }
        }

        return sb.toString();
    }
    
    public static boolean isImage(String filename){
        String extension = getExtension(filename);
        
        if(extension.equals("png") || extension.equals("jpg"))
            return true;
        return false;
    }
}
