package Models;

import java.io.Serializable;
import java.util.ArrayList;

public class Chatroom implements Serializable {

    int id;
    String title;

    int managerId;

    ArrayList<Person> people;
    ArrayList<ChatMessage> messages;

    public Chatroom(int id) {
        this.id = id;

        this.people = new ArrayList<>();
        this.messages = new ArrayList<>();
    }

    public Chatroom(int id, String title, int manager) {
        this.id = id;
        this.managerId = manager;
        this.title = title;
        this.people = new ArrayList<>();
        this.messages = new ArrayList<>();
    }

    public Chatroom(int id, String title, int manager, ArrayList<Person> people, ArrayList<ChatMessage> messages) {
        this.id = id;
        this.title = title;
        this.managerId = manager;
        this.people = people;
        this.messages = messages;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public ArrayList<Person> getPeople() {
        return people;
    }

    public ArrayList<ChatMessage> getMessages() {
        return messages;
    }

    public int getManagerId() {
        return managerId;
    }

    public void setManagerId(int manager) {
        this.managerId = manager;
    }

    @Override
    public String toString() {
        return title;
    }

    public void setPeople(ArrayList<Person> people) {
        this.people = people;
    }

    public void setMessages(ArrayList<ChatMessage> messages) {
        this.messages = messages;
    }
    

}
