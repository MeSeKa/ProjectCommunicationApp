package Models;

import java.io.Serializable;

/**
 *
 * @author Mehmed Sefa
 */
public class FriendShip implements Serializable{
    Person person;
    Chatroom chatroom;

    public FriendShip(Person person, Chatroom chatroom) {
        this.person = person;
        this.chatroom = chatroom;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public Chatroom getChatroom() {
        return chatroom;
    }

    public void setChatroom(Chatroom chatroom) {
        this.chatroom = chatroom;
    }
    
    
    
}
