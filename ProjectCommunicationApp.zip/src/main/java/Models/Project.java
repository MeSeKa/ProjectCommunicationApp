package Models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Mehmed Sefa
 */
public class Project implements Serializable {

    int id;
    String title;
    int managerId;

    ArrayList<Integer> chatRoomIds;
    ArrayList<Person> coworkers;
    String createdAt;

    public Project(int id, String title, int managerId, ArrayList<Person> coworkers, String createdAt) {
        this.id = id;
        this.title = title;
        this.managerId = managerId;
        this.coworkers = coworkers;
        this.createdAt = createdAt;
    }

    public Project(int id, String title, int manager, ArrayList<Person> coworkers, ArrayList<Integer> chatrooms, String createdAt) {
        this.id = id;
        this.title = title;
        this.managerId = manager;
        this.createdAt = createdAt;
        this.chatRoomIds = chatrooms;
        this.coworkers = coworkers;
    }

    public Project(String title, int manager) {
        this.title = title;
        this.managerId = manager;
    }

    @Override
    public String toString() {
        return title + " : " + createdAt;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getManagerId() {
        return managerId;
    }

    public void setManagerId(int managerId) {
        this.managerId = managerId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ArrayList<Integer> getChatRoomIds() {
        return chatRoomIds;
    }

    public void setChatRoomIds(ArrayList<Integer> chatRoomIds) {
        this.chatRoomIds = chatRoomIds;
    }

    public ArrayList<Person> getCoworkers() {
        return coworkers;
    }

    public void setCoworkers(ArrayList<Person> coworkers) {
        this.coworkers = coworkers;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    
}
