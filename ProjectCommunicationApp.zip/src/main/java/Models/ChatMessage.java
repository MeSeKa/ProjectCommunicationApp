package Models;

import java.io.Serializable;

/**
 *
 * @author Mehmed Sefa
 */
public class ChatMessage implements Serializable{
    int senderId;
    int chatroomId;
    String content;
    String sendAt;

    public ChatMessage(int senderId,int chatroomId, String content, String sendAt) {
        this.senderId = senderId;
        this.chatroomId= chatroomId;
        this.content = content;
        this.sendAt = sendAt;
    }

    public int getSenderId() {
        return senderId;
    }

    public void setSenderId(int senderId) {
        this.senderId = senderId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getSendAt() {
        return sendAt;
    }

    public void setSendAt(String sendAt) {
        this.sendAt = sendAt;
    }

    public int getChatroomId() {
        return chatroomId;
    }

    public void setChatroomId(int chatroomId) {
        this.chatroomId = chatroomId;
    }

    @Override
    public String toString() {
        return content + "\n sender+ " + senderId + " date:"+ sendAt;
    }
    
    
    
}
