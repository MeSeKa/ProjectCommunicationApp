package Client;

import Models.ChatMessageWithFile;
import Models.ChatMessage;
import Models.Chatroom;
import Models.FriendShip;
import Models.Person;
import Models.Project;
import NetworkModels.LoginInformation;
import NetworkModels.Message;
import NetworkModels.MessageType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Mehmed Sefa
 */
public class Client extends Thread {

    Person person;
    Socket socket;
    ClientFrame frame;

    ObjectOutputStream sOutput;
    ObjectInputStream sInput;

    boolean isRunning;

    public ClientFrame getFrame() {
        return frame;
    }

    public void setFrame(ClientFrame frame) {
        this.frame = frame;
    }

    public Client() {
        isRunning = true;
    }

    @Override
    public void run() {
        frame = new ClientFrame(this.person, this);
        frame.setVisible(true);
        while (isRunning) {
            try {
                Message receivedMessage = (Message) sInput.readObject();

                switch (receivedMessage.getMessageType()) {
                    case Person:
                        login(receivedMessage);
                        break;
                    case RequestProjects:
                        receiveProjects(receivedMessage);
                        break;
                    case RequestChatrooms:
                        receiveChatrooms(receivedMessage);
                        break;
                    case RequestAllChatroomMessages:
                        receiveMessagesForChatrooms(receivedMessage);
                        break;
                    case RequestFriendShips:
                        receiveFriendShips(receivedMessage);
                        break;
                    case RequestAllFriendShipMessages:
                        receiveMessagesForFriendships(receivedMessage);
                        break;

                    case Approve:
                        ApproveWrongMessageReceive(receivedMessage);
                        break;
                    case Wrong:
                        ApproveWrongMessageReceive(receivedMessage);
                        break;

                    case SingleChatMessage:
                        frame.AddNewMessage((ChatMessage) receivedMessage.getContent());
                        break;
                        
                    case MessageWithFile:
                        frame.AddNewMessage((ChatMessage) receivedMessage.getContent());
                        break;
                    default:
                        throw new AssertionError();
                }

            } catch (IOException ex) {
                Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void Disconnect() throws IOException {
        isRunning = false;
        socket.close();
    }

    boolean TryToLoginServer(String ip, int port, String username, String password) {

        try {
            Socket socket = new Socket(ip, port);
            this.socket = socket;
            this.sOutput = new ObjectOutputStream(new DataOutputStream(socket.getOutputStream()));
            this.sInput = new ObjectInputStream(new DataInputStream(socket.getInputStream()));

            //Send login Information
            LoginInformation loginInformation = new LoginInformation(username, password);
            Message sendingMessage = new Message(MessageType.LoginInformation, loginInformation);
            sOutput.writeObject(sendingMessage);

        } catch (IOException ex) {
            Logger.getLogger(ClientFrame.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;

    }

    void login(Message receivedMessage) {
        this.person = (Person) receivedMessage.getContent();
        frame.person = person;
        frame.SetFrameConfigurations(person);
    }

    boolean TryToRegisterServer(String ip, int port, Person person) {
        try {
            Socket socket = new Socket(ip, port);
            this.socket = socket;
            this.sOutput = new ObjectOutputStream(new DataOutputStream(socket.getOutputStream()));
            this.sInput = new ObjectInputStream(new DataInputStream(socket.getInputStream()));

            //Send register Information
            Message sendingMessage = new Message(MessageType.RegisterInformation, person);
            sOutput.writeObject(sendingMessage);

        } catch (IOException ex) {
            Logger.getLogger(ClientFrame.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }

    boolean TryToCreateProject(String title) {
        try {
            Message sendingMessage = new Message(MessageType.CreateProject, new Project(title, person.getId()));
            sOutput.writeObject(sendingMessage);

        } catch (IOException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }

    boolean TryToCreateChatroom(String title, int projectId, int manager) {
        try {
            //instead of giving chatroom id, we gaves project Id 
            Message sendingMessage = new Message(MessageType.CreateChatroom, new Chatroom(projectId, title, manager));
            sOutput.writeObject(sendingMessage);

        } catch (IOException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }

    boolean ApproveWrongMessageReceive(Message receivedMessage) throws IOException, ClassNotFoundException {

        if (receivedMessage.getMessageType() == MessageType.Approve) {
            JOptionPane.showMessageDialog(null, receivedMessage.getContent());
            return true;
        } else if (receivedMessage.getMessageType() == MessageType.Wrong) {
            JOptionPane.showMessageDialog(null, receivedMessage.getContent().toString(), "ERROR", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return false;
    }

    boolean serverProjectRequest() {
        Message sendingMessage = new Message(MessageType.RequestProjects, this.person);
        try {
            sOutput.writeObject(sendingMessage);

        } catch (IOException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

        return true;
    }

    void receiveProjects(Message receivedMessage) {
        ArrayList<Project> projects = (ArrayList<Project>) receivedMessage.getContent();
        frame.ReceiveProjects(projects);
    }

    boolean requestChatrooms() {
        Message sendingMessage = new Message(MessageType.RequestChatrooms, this.person);
        try {
            sOutput.writeObject(sendingMessage);

        } catch (IOException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }

    void receiveChatrooms(Message receivedMessage) {
        ArrayList<Chatroom> chatrooms = (ArrayList<Chatroom>) receivedMessage.getContent();
        frame.ReceiveChatrooms(chatrooms);
    }

    boolean TryToCreateFriendShip(int newFriendId) {

        try {
            Message sendingMessage = new Message(MessageType.CreateFriendShip, newFriendId);
            sOutput.writeObject(sendingMessage);
        } catch (IOException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }

    boolean requestFriendShips() {
        Message sendingMessage = new Message(MessageType.RequestFriendShips, this.person);
        try {
            sOutput.writeObject(sendingMessage);

        } catch (IOException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }

    void receiveFriendShips(Message receivedMessage) {
        ArrayList<FriendShip> friendShips = (ArrayList<FriendShip>) receivedMessage.getContent();
        frame.ReceiveFriendShips(friendShips);
    }

    boolean TryToJoinProject(int projectId) {
        try {
            //instead of giving chatroom id, we gaves project Id 
            Message sendingMessage = new Message(MessageType.JoinProject, projectId);
            sOutput.writeObject(sendingMessage);

        } catch (IOException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }

    boolean TryToAddFriendToChatroom(int friendId, int chatroomId) {

        ArrayList<Integer> friendAndChatroom = new ArrayList<>();
        friendAndChatroom.add((Integer) friendId);
        friendAndChatroom.add((Integer) chatroomId);

        try {
            //instead of giving chatroom id, we gaves project Id 
            Message sendingMessage = new Message(MessageType.AddFriendToChatroom, friendAndChatroom);
            sOutput.writeObject(sendingMessage);

            return true;
        } catch (IOException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    boolean requestChatMessagesForThisChatrooms(ArrayList<Chatroom> rooms) {
        Message sendingMessage = new Message(MessageType.RequestAllChatroomMessages, rooms);
        try {
            sOutput.writeObject(sendingMessage);

        } catch (IOException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }

    void receiveMessagesForChatrooms(Message receivedMessage) {
        ArrayList<Chatroom> chatrooms = (ArrayList<Chatroom>) receivedMessage.getContent();
        frame.ReceiveMessagesForChatrooms(chatrooms);
    }

    boolean TryToSendMessage(String text, int chatroomId) {

        ChatMessage chatMessage = new ChatMessage(person.getId(), chatroomId, text, currentDate());

        try {
            //instead of giving chatroom id, we gaves project Id 
            Message sendingMessage = new Message(MessageType.SingleChatMessage, chatMessage);
            sOutput.writeObject(sendingMessage);

            return true;
        } catch (IOException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }

    boolean TryToSendMessageWithFile(String text, File file,  int chatroomId) {

        ChatMessageWithFile chatMessage = new ChatMessageWithFile(person.getId(),
                chatroomId,
                text,
                currentDate(),
                getFileBytes(file),
                file.getName());

        try {
            //instead of giving chatroom id, we gaves project Id 
            Message sendingMessage = new Message(MessageType.MessageWithFile, chatMessage);
            sOutput.writeObject(sendingMessage);

            return true;
        } catch (IOException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }

    String currentDate() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
    }

    boolean requestMessagesForFriendships(ArrayList<FriendShip> friendShips) {
        Message sendingMessage = new Message(MessageType.RequestAllFriendShipMessages, friendShips);
        try {
            sOutput.writeObject(sendingMessage);

        } catch (IOException ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }

    void receiveMessagesForFriendships(Message receivedMessage) {
        ArrayList<FriendShip> friendShips = (ArrayList<FriendShip>) receivedMessage.getContent();
        frame.ReceiveMessagesForFriendShips(friendShips);
    }
    
    
    byte[] getFileBytes(File file){
        try {
            FileInputStream fileInputStream = new FileInputStream(file);
            byte [] fileContent = new byte[(int)file.length()];
            fileInputStream.read(fileContent);
            return  fileContent;
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ClientFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ClientFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        System.out.println("FILE NULL");
        return null;
    }

}
