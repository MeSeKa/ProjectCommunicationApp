package Client;


import GUIModels.ChatRoomUI;
import GUIModels.IconList;
import Models.ChatMessageWithFile;
import Models.Chatroom;
import Models.ChatMessage;
import Models.FriendShip;
import Models.Person;
import Models.Project;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.filechooser.FileSystemView;

/**
 *
 * @author Mehmed Sefa
 */
public class ClientFrame extends javax.swing.JFrame {

    /**
     * Creates new form ClientFrame
     */
    boolean isFileAttached = false;
    File selectedFile;

    Person person;

    ArrayList<Project> projects;

    ArrayList<Chatroom> chatrooms;

    Chatroom activeRoom;

    Client client;

    ArrayList<FriendShip> friendShips;
    Person selectedFriend;
    private ChatRoomUI chatRoomUI;
    private IconList friendShipUI;

    public ClientFrame(Person person, Client client) {
        initComponents();

        this.person = person;
        this.client = client;

        SetFrameConfigurations(this.person);

        activeRoom = null;
    }

    void SetFrameConfigurations(Person p) {
        //Personal informations set
        person = p;
        if (person == null) {
            return;
        }
        clientName.setText(person.getName());
        if (person.getIcon() != null) {

            Image img = person.getIcon().getImage();
            Image imgScale = img.getScaledInstance(icon.getWidth(), icon.getHeight(), Image.SCALE_SMOOTH);
            ImageIcon scaledImage = new ImageIcon(imgScale);

            icon.setIcon(scaledImage);
        } else {
            System.out.println("Person's icon is null");
        }
        clientIdLabel.setText(person.getId() + "");

        requestProjects();
        requestChatrooms();
        requestFriendShips();
        
        messagesPanel.setLayout(new BorderLayout());
        chatRoomUI = new ChatRoomUI();
        
        messagesPanel.add(chatRoomUI, BorderLayout.CENTER);
        

        friendShipPanel.setLayout(new BorderLayout());
        friendShipUI = new IconList(this);
        friendShipPanel.add(friendShipUI);
        friendShipPanel.revalidate();
        friendShipPanel.repaint();

        SetSendingFileVisible(isFileAttached);
        Chat.add(messagesPanel, BorderLayout.CENTER);
        Chat.add(sendingFilePanel, BorderLayout.CENTER);
        Chat.add(sendingMessagePanel, BorderLayout.CENTER);
        this.add(Chat, BorderLayout.CENTER);
        
        
    }

    void requestProjects() {
        if (client == null) {
            return;
        }
        if (!client.serverProjectRequest()) {
            JOptionPane.showMessageDialog(null, "Project could not requested succesfully");
        }

    }

    public void ReceiveProjects(ArrayList<Project> receivedProjects) {
        this.projects = receivedProjects;
        updateProjectsUI();

    }

    void updateProjectsUI() {
        if (projects == null) {
            System.out.println(" PROJECTS NULL ");
            return;
        }

        projectComboBoxModel = new DefaultComboBoxModel<>();
        projectListModel = new DefaultListModel<>();
        for (Project project : projects) {
            projectListModel.addElement(project);
            if (project.getManagerId() == person.getId()) {
                projectComboBoxModel.addElement(project);
            }
        }
        projectList.setModel(projectListModel);
        projectToCreateChatroom.setModel(projectComboBoxModel);
    }

    void requestChatrooms() {
        if (client == null) {
            return;
        }
        if (!client.requestChatrooms()) {
            JOptionPane.showMessageDialog(null, "Chatrooms could not requested succesfully");
        }
    }

    public void ReceiveChatrooms(ArrayList<Chatroom> receivedChatrooms) {
        chatrooms = receivedChatrooms;
        requestMessagesForChatrooms();
    }

    void updateChatrooms() {
        if (chatrooms == null) {
            System.out.println(" CHATROOMS NULL ");
            return;
        }

        chatroomListModel = new DefaultListModel<>();
        chatroomComboBoxModel = new DefaultComboBoxModel<>();
        for (Chatroom room : chatrooms) {
            chatroomListModel.addElement(room);
            if (room.getManagerId() == person.getId()) {
                chatroomComboBoxModel.addElement(room);
            }
        }

        chatroomsList.setModel(chatroomListModel);
        chatroomsToAddFriend.setModel(chatroomComboBoxModel);
    }

    void SetCoworkerListToThis(ArrayList<Person> list) {

        coworkerListModel = new DefaultListModel<>();
        for (Person coworker : list) {
            coworkerListModel.addElement(coworker);
        }
        coworkerList.setModel(coworkerListModel);
    }

    void SetActiveChatroomToThis(Chatroom newSelectedRoom) {
        if (newSelectedRoom == null) {
            System.out.println("SELECTED CHAT ROOM IS NULL");
            return;
        }

        activeRoom = newSelectedRoom;

        chatRoomUI.updateChatRoom(activeRoom, person.getId());

        StringBuilder builder = new StringBuilder();
        for (Person person1 : activeRoom.getPeople()) {
            builder.append(person1.getName() + ", ");
        }
        peopleOfActiveChat.setText(builder.toString());
    }

    private void CreateProject() {
        this.client.TryToCreateProject(createProjectField.getText());
        this.requestProjects();
    }

    private void CreateChatroom() {
        int projectId = -1;
        if (isDependOnAProject.isSelected()) {
            if (projectToCreateChatroom.getSelectedIndex() == -1 || projectComboBoxModel.getElementAt(projectToCreateChatroom.getSelectedIndex()) == null) {
                JOptionPane.showMessageDialog(null, "If chatroom depend on a project you should choose the project");
                return;
            }
            projectId = (projectComboBoxModel.getElementAt(projectToCreateChatroom.getSelectedIndex())).getId();
        }
        if (newChatroomTitleField.getText().isBlank()) {
            JOptionPane.showMessageDialog(null, "Type a chatroom title or name first");
            return;

        }
        client.TryToCreateChatroom(newChatroomTitleField.getText(), projectId, person.getId());
        this.requestChatrooms();
    }

    private void AddFriend(int newFriendId) {
        if (newFriendId == person.getId()) {
            JOptionPane.showMessageDialog(null, "You can not add yourself as a friend");
            return;
        }
        this.client.TryToCreateFriendShip(newFriendId);
        this.requestFriendShips();
    }

    private void requestFriendShips() {
        if (client == null) {
            return;
        }
        if (!client.requestFriendShips()) {
            JOptionPane.showMessageDialog(null, "Friendships could not requested succesfully");
        }
    }

    public void ReceiveFriendShips(ArrayList<FriendShip> receivedFriendShips) {
        friendShips = receivedFriendShips;
        requestMessagesForFriendships();//NOT IMPLEMENTED YET
        updateFriendShips();
    }

    void updateFriendShips() {
        if (friendShips == null) {
            System.out.println(" FRIENDSHIPS NULL ");
            return;
        }

        friendShipUI.UpdateIconList(friendShips);
    }

    void JoinNewProject() {
        int projectId = Integer.parseInt(projectIdFieldToJoin.getText());
        client.TryToJoinProject(projectId);
        this.requestProjects();
        this.requestChatrooms();
    }

    private void SelectProject() {
        int index = projectList.getSelectedIndex();
        //System.out.println("index "+index);
        if (index < 0) {
            return;
        }
        Project selectedProject = projectListModel.elementAt(projectList.getSelectedIndex());
        //System.out.println("selected project: "+selectedProject);
        ArrayList<Person> coworkerOfSelectedProject = selectedProject.getCoworkers();
        //System.out.println("coworkerOfSelectedProject "+coworkerOfSelectedProject);

        SetCoworkerListToThis(coworkerOfSelectedProject);

        selectedProjectName.setText(selectedProject.getTitle());
        selectedProjectId.setText(selectedProject.getId() + "");
        if (selectedProject.getManagerId() == person.getId()) {
            selectedProjectId.setEchoChar((char) 0);
        } else {
            selectedProjectId.setEchoChar('\u2022');
        }
    }

    public void SelectFriend(int id) {

        selectedFriend = null;
        for (FriendShip friendShip : friendShips) {
            if (friendShip.getPerson().getId() == id) {
                selectedFriend = friendShip.getPerson();
                SetActiveChatroomToThis(friendShip.getChatroom());
                break;
            }
        }
        if (selectedFriend == null) {
            return;
        }

        Image img = selectedFriend.getIcon().getImage();
        Image imgScale = img.getScaledInstance(selectedFriendIcon.getWidth(), selectedFriendIcon.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledImage = new ImageIcon(imgScale);

        selectedFriendIcon.setIcon(scaledImage);
        selectedFriendName.setText(selectedFriend.getName());

    }

    private void AddFriendToChatroom() {
        if (selectedFriend == null) {
            JOptionPane.showMessageDialog(null, "You should select a friend first");
            return;
        }

        Chatroom selectedChatroom = chatroomComboBoxModel.getElementAt(chatroomsToAddFriend.getSelectedIndex());
        if (selectedChatroom == null) {
            JOptionPane.showMessageDialog(null, "You should select a chatroom first");
            return;
        }

        client.TryToAddFriendToChatroom(selectedFriend.getId(), selectedChatroom.getId());

        requestChatrooms();

    }

    private void SelectChatroom() {

        Chatroom newSelectedRoom = null;

        int index = chatroomsList.getSelectedIndex();
        if (index < 0) {
            return;
        }
        //System.out.println("index "+index);
        newSelectedRoom = chatroomListModel.elementAt(index);

        if (newSelectedRoom != null && newSelectedRoom != activeRoom) {
            SetActiveChatroomToThis(newSelectedRoom);
        }
    }

    private void requestMessagesForFriendships() {
        if (client == null) {
            return;
        }
        if (!client.requestMessagesForFriendships(friendShips)) {
            JOptionPane.showMessageDialog(null, "requestMessagesForFriendships failed");
            return;
        }
    }

    public void ReceiveMessagesForFriendShips(ArrayList<FriendShip> receivedFriendShips) {
        friendShips = receivedFriendShips;
        updateFriendShips();

    }

    private void requestMessagesForChatrooms() {
        if (client == null) {
            return;
        }
        if (!client.requestChatMessagesForThisChatrooms(chatrooms)) {
            JOptionPane.showMessageDialog(null, "requestMessagesForChatrooms failed");
            return;
        }
    }

    public void ReceiveMessagesForChatrooms(ArrayList<Chatroom> receivedChatrooms) {
        chatrooms = receivedChatrooms;
        updateChatrooms();
    }

    private void SendMessage() {
        String text = sendingMessageTextField.getText();

        if (activeRoom == null) {
            JOptionPane.showMessageDialog(null, "You should choose a chatroom first");
            return;
        }

        if (isFileAttached) {
            client.TryToSendMessageWithFile(text, selectedFile, activeRoom.getId());
        } else {
            client.TryToSendMessage(text, activeRoom.getId());
        }

        sendingMessageTextField.setText("");
        isFileAttached = false;
        SetSendingFileVisible(isFileAttached);

    }

    public void AddNewMessage(ChatMessage message) {
        //System.out.println(message.getSenderId() + message.getContent());
        for (Chatroom chatroom : chatrooms) {
            if (chatroom.getId() == message.getChatroomId()) {
                chatroom.getMessages().add(message);
                if (activeRoom.getId() == chatroom.getId()) {
                    SetActiveChatroomToThis(activeRoom);
                }
                break;
            }
        }

        for (FriendShip friendShip : friendShips) {
            if (friendShip.getChatroom().getId() == message.getChatroomId()) {
                friendShip.getChatroom().getMessages().add(message);
                if (activeRoom != null && activeRoom.getId() == friendShip.getChatroom().getId()) {
                    SetActiveChatroomToThis(activeRoom);
                }
                break;
            }
        }
    }
    
    
    private void ChooseFileToSend() {
        JFileChooser j = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());

        // invoke the showsOpenDialog function to show the save dialog
        int r = j.showOpenDialog(null);

        // if the user selects a file
        if (r == JFileChooser.APPROVE_OPTION) {
            // set the label to the path of the selected file
            String imagePath = j.getSelectedFile().getAbsolutePath();
            filePath.setText(imagePath);
            SetSendingImageIcon(imagePath);
            isFileAttached = true;
            SetSendingFileVisible(true);
            selectedFile = j.getSelectedFile();

        } // if the user cancelled the operation
        else {
            filePath.setText("the user cancelled the operation");
            isFileAttached = false;
            SetSendingFileVisible(false);
        }
    }

    void SetSendingImageIcon(String imagePath) {
        if (!ChatMessageWithFile.isImage(imagePath)) {
            return;
        }
        Image img = (new ImageIcon(imagePath)).getImage();
        Image imgScale = img.getScaledInstance(iconPlaceHolder.getWidth(), iconPlaceHolder.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledImage = new ImageIcon(imgScale);

        iconPlaceHolder.setIcon(scaledImage);
    }

    void SetSendingFileVisible(boolean set) {
        sendingFilePanel.setVisible(set);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        clientName = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        HomePanel = new javax.swing.JPanel();
        createProjectField = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        createProjectButton = new javax.swing.JButton();
        joinNewProjectButton = new javax.swing.JButton();
        projectIdFieldToJoin = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        ProjectsPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        projectList = new javax.swing.JList<>();
        jScrollPane4 = new javax.swing.JScrollPane();
        coworkerList = new javax.swing.JList<>();
        coworkerIdField = new javax.swing.JTextField();
        AddCoworkerAsFriendButton = new javax.swing.JButton();
        selectedProjectInformationLabel = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        selectedProjectId = new javax.swing.JPasswordField();
        jLabel9 = new javax.swing.JLabel();
        selectedProjectName = new javax.swing.JTextField();
        ChatroomsPanel = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        chatroomsList = new javax.swing.JList<>();
        projectToCreateChatroom = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        newChatroomTitleField = new javax.swing.JTextField();
        createNewChatroom = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        isDependOnAProject = new javax.swing.JCheckBox();
        jLabel6 = new javax.swing.JLabel();
        FriendsPanel = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        selectedFriendIcon = new javax.swing.JLabel();
        chatroomsToAddFriend = new javax.swing.JComboBox<>();
        selectedFriendName = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        addFriendToChatroomButton = new javax.swing.JButton();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTextPane2 = new javax.swing.JTextPane();
        friendsScrollPanel = new javax.swing.JScrollPane();
        friendShipPanel = new javax.swing.JPanel();
        newFriendIdField = new javax.swing.JTextField();
        AddFriendButton = new javax.swing.JButton();
        Chat = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        messagesPanel = new javax.swing.JPanel();
        sendingFilePanel = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        filePath = new javax.swing.JLabel();
        iconPlaceHolder = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        sendingMessagePanel = new javax.swing.JPanel();
        sendObjectButton = new javax.swing.JButton();
        sendingMessageTextField = new javax.swing.JTextField();
        sendMessageButton = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        peopleOfActiveChat = new javax.swing.JTextPane();
        icon = new javax.swing.JLabel();
        clientIdLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Client Frame Application");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        clientName.setText("NAME");
        clientName.setBorder(javax.swing.BorderFactory.createTitledBorder("Name"));

        jTabbedPane1.setBackground(new java.awt.Color(204, 255, 255));
        jTabbedPane1.setForeground(new java.awt.Color(102, 102, 102));
        jTabbedPane1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jTabbedPane1StateChanged(evt);
            }
        });

        jLabel3.setText("Project Name");

        createProjectButton.setText("Create Project");
        createProjectButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createProjectButtonActionPerformed(evt);
            }
        });

        joinNewProjectButton.setText("Join");
        joinNewProjectButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                joinNewProjectButtonActionPerformed(evt);
            }
        });

        jLabel4.setText("Project ID");

        javax.swing.GroupLayout HomePanelLayout = new javax.swing.GroupLayout(HomePanel);
        HomePanel.setLayout(HomePanelLayout);
        HomePanelLayout.setHorizontalGroup(
            HomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HomePanelLayout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addGroup(HomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(HomePanelLayout.createSequentialGroup()
                        .addGroup(HomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel3)
                            .addComponent(createProjectField)
                            .addComponent(projectIdFieldToJoin, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(HomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(createProjectButton)
                            .addComponent(joinNewProjectButton, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel4))
                .addContainerGap(86, Short.MAX_VALUE))
        );
        HomePanelLayout.setVerticalGroup(
            HomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HomePanelLayout.createSequentialGroup()
                .addGap(139, 139, 139)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(HomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(createProjectField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(createProjectButton))
                .addGap(14, 14, 14)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(HomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(projectIdFieldToJoin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(joinNewProjectButton))
                .addContainerGap(337, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Main", HomePanel);

        ProjectsPanel.setForeground(new java.awt.Color(255, 255, 255));

        projectList.setBorder(javax.swing.BorderFactory.createTitledBorder("Projects"));
        projectList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                projectListMouseClicked(evt);
            }
        });
        projectList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                projectListValueChanged(evt);
            }
        });
        jScrollPane1.setViewportView(projectList);
        projectList.getAccessibleContext().setAccessibleDescription("");

        coworkerList.setBorder(javax.swing.BorderFactory.createTitledBorder("Coworkers"));
        coworkerList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                coworkerListValueChanged(evt);
            }
        });
        jScrollPane4.setViewportView(coworkerList);

        coworkerIdField.setEditable(false);
        coworkerIdField.setBorder(javax.swing.BorderFactory.createTitledBorder("Selected Coworker"));

        AddCoworkerAsFriendButton.setText("Add Friend");
        AddCoworkerAsFriendButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddCoworkerAsFriendButtonActionPerformed(evt);
            }
        });

        selectedProjectInformationLabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        selectedProjectInformationLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        selectedProjectInformationLabel.setText("Project");

        jLabel8.setText("Selected Project Id: (Only manager can see)");

        selectedProjectId.setEditable(false);
        selectedProjectId.setText("jPasswordField1");

        jLabel9.setText("Selected Project Name:");

        selectedProjectName.setEditable(false);

        javax.swing.GroupLayout ProjectsPanelLayout = new javax.swing.GroupLayout(ProjectsPanel);
        ProjectsPanel.setLayout(ProjectsPanelLayout);
        ProjectsPanelLayout.setHorizontalGroup(
            ProjectsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ProjectsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ProjectsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ProjectsPanelLayout.createSequentialGroup()
                        .addGroup(ProjectsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(selectedProjectInformationLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ProjectsPanelLayout.createSequentialGroup()
                                .addComponent(coworkerIdField)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(AddCoworkerAsFriendButton))
                            .addComponent(jLabel8)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 279, Short.MAX_VALUE)
                            .addComponent(selectedProjectId)
                            .addComponent(jLabel9))
                        .addContainerGap())
                    .addComponent(selectedProjectName)))
        );
        ProjectsPanelLayout.setVerticalGroup(
            ProjectsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ProjectsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(ProjectsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ProjectsPanelLayout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addContainerGap())
                    .addGroup(ProjectsPanelLayout.createSequentialGroup()
                        .addComponent(selectedProjectInformationLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(selectedProjectName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(selectedProjectId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(ProjectsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(coworkerIdField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(AddCoworkerAsFriendButton, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(107, 248, Short.MAX_VALUE))))
        );

        jTabbedPane1.addTab("Projects", ProjectsPanel);

        chatroomsList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                chatroomsListValueChanged(evt);
            }
        });
        jScrollPane6.setViewportView(chatroomsList);

        projectToCreateChatroom.setEnabled(false);

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("New Chatroom Creation");

        jLabel5.setText("Name");

        createNewChatroom.setText("Create New Chatroom");
        createNewChatroom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createNewChatroomActionPerformed(evt);
            }
        });

        jTextPane1.setEditable(false);
        jTextPane1.setText("Everyone can create a chatroom, but only project managers can create new chatroom under a certain project");
        jTextPane1.setToolTipText("");
        jScrollPane5.setViewportView(jTextPane1);

        isDependOnAProject.setText("Is depends on a project ?");
        isDependOnAProject.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                isDependOnAProjectStateChanged(evt);
            }
        });

        jLabel6.setText("Chatrooms");

        javax.swing.GroupLayout ChatroomsPanelLayout = new javax.swing.GroupLayout(ChatroomsPanel);
        ChatroomsPanel.setLayout(ChatroomsPanelLayout);
        ChatroomsPanelLayout.setHorizontalGroup(
            ChatroomsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ChatroomsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(ChatroomsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ChatroomsPanelLayout.createSequentialGroup()
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(ChatroomsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(ChatroomsPanelLayout.createSequentialGroup()
                                .addComponent(isDependOnAProject)
                                .addGap(71, 71, 71))
                            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(projectToCreateChatroom, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(createNewChatroom, javax.swing.GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE)
                            .addComponent(newChatroomTitleField, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(ChatroomsPanelLayout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                    .addComponent(jLabel6))
                .addContainerGap())
        );
        ChatroomsPanelLayout.setVerticalGroup(
            ChatroomsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ChatroomsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ChatroomsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 550, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ChatroomsPanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(newChatroomTitleField, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(isDependOnAProject)
                        .addGap(8, 8, 8)
                        .addComponent(projectToCreateChatroom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(createNewChatroom, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(150, 150, 150))))
        );

        jTabbedPane1.addTab("Chatrooms", ChatroomsPanel);

        jLabel10.setText("Selected Friend");

        selectedFriendName.setEditable(false);
        selectedFriendName.setText("Name");

        jLabel11.setText("Name:");

        jLabel12.setText("Chatroom");

        addFriendToChatroomButton.setText("Add Selected Friend To Chatroom");
        addFriendToChatroomButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addFriendToChatroomButtonActionPerformed(evt);
            }
        });

        jTextPane2.setText("(Only Chatroom Managers can add their friends to the room.)");
        jScrollPane7.setViewportView(jTextPane2);

        javax.swing.GroupLayout friendShipPanelLayout = new javax.swing.GroupLayout(friendShipPanel);
        friendShipPanel.setLayout(friendShipPanelLayout);
        friendShipPanelLayout.setHorizontalGroup(
            friendShipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 304, Short.MAX_VALUE)
        );
        friendShipPanelLayout.setVerticalGroup(
            friendShipPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 686, Short.MAX_VALUE)
        );

        friendsScrollPanel.setViewportView(friendShipPanel);

        newFriendIdField.setBorder(javax.swing.BorderFactory.createTitledBorder("New Friend ID"));

        AddFriendButton.setText("Add Friend");
        AddFriendButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddFriendButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout FriendsPanelLayout = new javax.swing.GroupLayout(FriendsPanel);
        FriendsPanel.setLayout(FriendsPanelLayout);
        FriendsPanelLayout.setHorizontalGroup(
            FriendsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FriendsPanelLayout.createSequentialGroup()
                .addComponent(friendsScrollPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(FriendsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(addFriendToChatroomButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(chatroomsToAddFriend, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(FriendsPanelLayout.createSequentialGroup()
                        .addComponent(selectedFriendIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(FriendsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11)
                            .addComponent(selectedFriendName)))
                    .addGroup(FriendsPanelLayout.createSequentialGroup()
                        .addGroup(FriendsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12)
                            .addComponent(jLabel10))
                        .addContainerGap(200, Short.MAX_VALUE))
                    .addGroup(FriendsPanelLayout.createSequentialGroup()
                        .addComponent(newFriendIdField)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(AddFriendButton))))
        );
        FriendsPanelLayout.setVerticalGroup(
            FriendsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FriendsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(FriendsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(friendsScrollPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 572, Short.MAX_VALUE)
                    .addGroup(FriendsPanelLayout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(10, 10, 10)
                        .addGroup(FriendsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(FriendsPanelLayout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(selectedFriendName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(selectedFriendIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(65, 65, 65)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(chatroomsToAddFriend, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(addFriendToChatroomButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(FriendsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(newFriendIdField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(AddFriendButton, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(68, 68, 68))))
        );

        jTabbedPane1.addTab("Friends", FriendsPanel);

        Chat.setBackground(new java.awt.Color(204, 255, 204));
        Chat.setForeground(new java.awt.Color(0, 153, 102));
        Chat.setFocusCycleRoot(true);
        Chat.setFocusTraversalPolicyProvider(true);

        jLabel1.setText("Active Chat");

        jLabel2.setText("People:");

        messagesPanel.setBackground(new java.awt.Color(255, 153, 153));
        messagesPanel.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        messagesPanel.setFocusCycleRoot(true);
        messagesPanel.setFocusTraversalPolicyProvider(true);

        javax.swing.GroupLayout messagesPanelLayout = new javax.swing.GroupLayout(messagesPanel);
        messagesPanel.setLayout(messagesPanelLayout);
        messagesPanelLayout.setHorizontalGroup(
            messagesPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 325, Short.MAX_VALUE)
        );
        messagesPanelLayout.setVerticalGroup(
            messagesPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 406, Short.MAX_VALUE)
        );

        jLabel13.setText("Path");

        filePath.setText("   ");

        iconPlaceHolder.setText(" ");

        jLabel14.setText("Selected File to Send:");

        javax.swing.GroupLayout sendingFilePanelLayout = new javax.swing.GroupLayout(sendingFilePanel);
        sendingFilePanel.setLayout(sendingFilePanelLayout);
        sendingFilePanelLayout.setHorizontalGroup(
            sendingFilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(sendingFilePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(iconPlaceHolder, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(sendingFilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(sendingFilePanelLayout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addContainerGap())
                    .addGroup(sendingFilePanelLayout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(filePath, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        sendingFilePanelLayout.setVerticalGroup(
            sendingFilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(sendingFilePanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(sendingFilePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel13)
                    .addComponent(filePath, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
            .addComponent(iconPlaceHolder, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        sendObjectButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/menu.png"))); // NOI18N
        sendObjectButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sendObjectButtonActionPerformed(evt);
            }
        });

        sendMessageButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/message.png"))); // NOI18N
        sendMessageButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sendMessageButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout sendingMessagePanelLayout = new javax.swing.GroupLayout(sendingMessagePanel);
        sendingMessagePanel.setLayout(sendingMessagePanelLayout);
        sendingMessagePanelLayout.setHorizontalGroup(
            sendingMessagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(sendingMessagePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(sendObjectButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sendingMessageTextField)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sendMessageButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        sendingMessagePanelLayout.setVerticalGroup(
            sendingMessagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, sendingMessagePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(sendingMessagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(sendMessageButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(sendingMessagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(sendObjectButton, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(sendingMessageTextField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        peopleOfActiveChat.setEditable(false);
        jScrollPane2.setViewportView(peopleOfActiveChat);

        javax.swing.GroupLayout ChatLayout = new javax.swing.GroupLayout(Chat);
        Chat.setLayout(ChatLayout);
        ChatLayout.setHorizontalGroup(
            ChatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ChatLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(ChatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(sendingMessagePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(messagesPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(sendingFilePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(ChatLayout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2)))
                .addContainerGap())
            .addGroup(ChatLayout.createSequentialGroup()
                .addGap(127, 127, 127)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        ChatLayout.setVerticalGroup(
            ChatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ChatLayout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGap(5, 5, 5)
                .addGroup(ChatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(messagesPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sendingFilePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sendingMessagePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        clientIdLabel.setText("ID");
        clientIdLabel.setBorder(javax.swing.BorderFactory.createTitledBorder("Your Id"));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(clientName, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(clientIdLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 592, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 294, Short.MAX_VALUE)
                        .addComponent(icon, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(Chat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(clientName, javax.swing.GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE)
                            .addComponent(clientIdLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTabbedPane1))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(icon, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Chat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 11, Short.MAX_VALUE))))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void projectListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_projectListValueChanged

        SelectProject();
    }//GEN-LAST:event_projectListValueChanged

    private void createProjectButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createProjectButtonActionPerformed
        CreateProject();
    }//GEN-LAST:event_createProjectButtonActionPerformed

    private void jTabbedPane1StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jTabbedPane1StateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_jTabbedPane1StateChanged

    private void joinNewProjectButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_joinNewProjectButtonActionPerformed
        // TODO add your handling code here:
        JoinNewProject();
    }//GEN-LAST:event_joinNewProjectButtonActionPerformed

    private void projectListMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_projectListMouseClicked
    }//GEN-LAST:event_projectListMouseClicked

    private void coworkerListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_coworkerListValueChanged
        // TODO add your handling code here:

        int index = coworkerList.getSelectedIndex();
        //System.out.println("index "+index);
        Person selectedPerson = coworkerListModel.elementAt(index);
        //System.out.println("selected project: "+selectedProject);
        coworkerIdField.setText(selectedPerson.getName());
    }//GEN-LAST:event_coworkerListValueChanged

    private void isDependOnAProjectStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_isDependOnAProjectStateChanged
        // TODO add your handling code here:
        projectToCreateChatroom.setEnabled(isDependOnAProject.isSelected());
    }//GEN-LAST:event_isDependOnAProjectStateChanged

    private void createNewChatroomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createNewChatroomActionPerformed
        // TODO add your handling code here:

        CreateChatroom();
    }//GEN-LAST:event_createNewChatroomActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        try {
            client.Disconnect();
        } catch (IOException ex) {
            Logger.getLogger(ClientFrame.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "DSCONNECTED");
        }
    }//GEN-LAST:event_formWindowClosing

    private void AddFriendButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddFriendButtonActionPerformed
        int newFriendId = Integer.parseInt(newFriendIdField.getText());
        AddFriend(newFriendId);
    }//GEN-LAST:event_AddFriendButtonActionPerformed

    private void AddCoworkerAsFriendButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddCoworkerAsFriendButtonActionPerformed
        // TODO add your handling code here:

        Person selectedPerson = coworkerListModel.elementAt(coworkerList.getSelectedIndex());
        int newFriendId = selectedPerson.getId();
        AddFriend(newFriendId);
    }//GEN-LAST:event_AddCoworkerAsFriendButtonActionPerformed

    private void addFriendToChatroomButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addFriendToChatroomButtonActionPerformed
        // TODO add your handling code here:
        AddFriendToChatroom();
    }//GEN-LAST:event_addFriendToChatroomButtonActionPerformed

    private void chatroomsListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_chatroomsListValueChanged
        // TODO add your handling code here:
        SelectChatroom();
    }//GEN-LAST:event_chatroomsListValueChanged

    private void sendMessageButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sendMessageButtonActionPerformed
        // TODO add your handling code here:
        SendMessage();
    }//GEN-LAST:event_sendMessageButtonActionPerformed

    private void sendObjectButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sendObjectButtonActionPerformed
        // TODO add your handling code here:
        ChooseFileToSend();
    }//GEN-LAST:event_sendObjectButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ClientFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ClientFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ClientFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ClientFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form 
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ClientFrame(new Person("NO NAME", null)).setVisible(true);
            }
        //</editor-fold>

        /* Create and display the form 
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ClientFrame(new Person("NO NAME", null)).setVisible(true);
            }
        //</editor-fold>

        /* Create and display the form 
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ClientFrame(new Person("NO NAME", null)).setVisible(true);
            }
        //</editor-fold>

        /* Create and display the form 
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ClientFrame(new Person("NO NAME", null)).setVisible(true);
            }
        });*/
    }

    DefaultListModel<Project> projectListModel = new DefaultListModel<>();
    DefaultListModel<ChatMessage> chatMessageListModel = new DefaultListModel<>();
    DefaultListModel<Person> coworkerListModel = new DefaultListModel<>();
    DefaultListModel<Chatroom> chatroomListModel = new DefaultListModel<>();
    DefaultComboBoxModel<Project> projectComboBoxModel = new DefaultComboBoxModel<>();
    DefaultListModel<Person> friendListModel = new DefaultListModel<>();
    DefaultComboBoxModel<Chatroom> chatroomComboBoxModel = new DefaultComboBoxModel<>();

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddCoworkerAsFriendButton;
    private javax.swing.JButton AddFriendButton;
    private javax.swing.JPanel Chat;
    private javax.swing.JPanel ChatroomsPanel;
    private javax.swing.JPanel FriendsPanel;
    private javax.swing.JPanel HomePanel;
    private javax.swing.JPanel ProjectsPanel;
    private javax.swing.JButton addFriendToChatroomButton;
    private javax.swing.JList<Chatroom> chatroomsList;
    private javax.swing.JComboBox<Chatroom> chatroomsToAddFriend;
    private javax.swing.JLabel clientIdLabel;
    private javax.swing.JLabel clientName;
    private javax.swing.JTextField coworkerIdField;
    private javax.swing.JList<Person> coworkerList;
    private javax.swing.JButton createNewChatroom;
    private javax.swing.JButton createProjectButton;
    private javax.swing.JTextField createProjectField;
    private javax.swing.JLabel filePath;
    private javax.swing.JPanel friendShipPanel;
    private javax.swing.JScrollPane friendsScrollPanel;
    private javax.swing.JLabel icon;
    private javax.swing.JLabel iconPlaceHolder;
    private javax.swing.JCheckBox isDependOnAProject;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextPane jTextPane1;
    private javax.swing.JTextPane jTextPane2;
    private javax.swing.JButton joinNewProjectButton;
    private javax.swing.JPanel messagesPanel;
    private javax.swing.JTextField newChatroomTitleField;
    private javax.swing.JTextField newFriendIdField;
    private javax.swing.JTextPane peopleOfActiveChat;
    private javax.swing.JTextField projectIdFieldToJoin;
    private javax.swing.JList<Project> projectList;
    private javax.swing.JComboBox<Project> projectToCreateChatroom;
    private javax.swing.JLabel selectedFriendIcon;
    private javax.swing.JTextField selectedFriendName;
    private javax.swing.JPasswordField selectedProjectId;
    private javax.swing.JLabel selectedProjectInformationLabel;
    private javax.swing.JTextField selectedProjectName;
    private javax.swing.JButton sendMessageButton;
    private javax.swing.JButton sendObjectButton;
    private javax.swing.JPanel sendingFilePanel;
    private javax.swing.JPanel sendingMessagePanel;
    private javax.swing.JTextField sendingMessageTextField;
    // End of variables declaration//GEN-END:variables

}
