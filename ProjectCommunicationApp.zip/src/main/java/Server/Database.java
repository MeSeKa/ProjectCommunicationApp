package Server;

import Models.Chatroom;
import Models.ChatMessage;
import Models.ChatMessageWithFile;
import Models.FriendShip;
import Models.Person;
import Models.Project;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author Mehmed Sefa
 */
public class Database {

    //Singleton
    static Database instance;

    private Database() {
    }

    //Variables
    Connection connection;

    public static void SetUpDatabase() {
        instance = new Database();
        instance.Connect();

    }

    public static Database Instance() {

        return instance;

    }

    void CheckConnection() {
        if (connection == null) {
            Connect();
        }
    }

    public void Connect() {
        try {
            String location = System.getProperty("user.dir");
            Class.forName("org.sqlite.JDBC");

            Connection connection = DriverManager.getConnection(("jdbc:sqlite:" + location + "\\information"));

            this.connection = connection;
            System.out.println("Succesfully connected to database");
            //JOptionPane.showMessageDialog(null, "Connected succesfully with" + connection);
            return;
        } catch (Exception e) {
            System.out.println("CAN NOT CONNECTED TO DATABASE");
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public static ImageIcon byteArrayToImageIcon(byte[] byteArray) {
        try {
            // Byte dizisini ByteArrayInputStream kullanarak BufferedImage'a dönüştür
            ByteArrayInputStream bis = new ByteArrayInputStream(byteArray);
            BufferedImage image = ImageIO.read(bis);

            // BufferedImage'i ImageIcon'a dönüştür
            return new ImageIcon(image);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static byte[] imageIconToByteArray(ImageIcon icon) {
        BufferedImage image = new BufferedImage(icon.getIconWidth(), icon.getIconHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics g = image.createGraphics();

        // ImageIcon'u BufferedImage'a çiz
        icon.paintIcon(null, g, 0, 0);
        g.dispose();

        // BufferedImage'i ByteArrayOutputStream kullanarak byte dizisine dönüştür
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            ImageIO.write(image, "jpg", baos); // JPEG formatında yaz
            baos.flush();
            byte[] byteArray = baos.toByteArray();
            baos.close();
            return byteArray;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public ArrayList<Project> getProjectsOfThis(Person person) throws SQLException {
        //TO DO
        //search in "project has people and projects"

        return getProjectsOfThis(person.getId());

    }

    public ArrayList<Project> getProjectsOfThis(int personId) throws SQLException {
        CheckConnection();

        String sql = "SELECT title,projectId FROM projectHasPeople, project "
                + "WHERE projectHasPeople.projectId = project.id "
                + "AND personId = " + personId + "";

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();

        ArrayList<Project> projects = new ArrayList<>();
        ArrayList<Integer> projectIds = new ArrayList<>();
        while (resultSet.next()) {
            projectIds.add(resultSet.getInt("projectId"));
        }

        for (Integer id : projectIds) {
            projects.add(getProject(id));
        }

        return projects;
    }

    public boolean CreatePerson(Person person) throws SQLException {

        CheckConnection();
        String sql = "INSERT INTO people (username,password,name,icon) values (?,?,?,?)";

        PreparedStatement preparedStatement = connection.prepareStatement(sql);

        preparedStatement.setString(1, person.getUsername());
        preparedStatement.setString(2, person.getPassword());
        preparedStatement.setString(3, person.getName());

        preparedStatement.setBytes(4, imageIconToByteArray(person.getIcon()));

        preparedStatement.execute();
        return true;

    }

    public Person getPerson(String username, String password) {
        //TO DO
        //SEARCH in "people"
        CheckConnection();
        String sql = "select * from people where username ='" + username + "' and password ='" + password + "'";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet != null && resultSet.getString(1) != null) {

                return new Person(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("username"),
                        byteArrayToImageIcon(resultSet.getBytes(5)));
            }

        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }

        return null;
    }

    public Project getProject(String title) throws SQLException {
        CheckConnection();
        String sql = "SELECT * from project LEFT JOIN projectHasChatrooms "
                + "ON project.id = projectHasChatrooms.projectId "
                + "WHERE title ='" + title + "'";

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();

        ArrayList<Integer> chatroomIds = new ArrayList<>();
        if (resultSet != null && resultSet.getString(1) != null) {
            int projectId = resultSet.getInt("id");
            int managerId = resultSet.getInt("managerId");
            String createdAt = resultSet.getString("createdAt");

            while (resultSet.next()) {
                chatroomIds.add(resultSet.getInt("chatroomId"));
            }

            ArrayList<Person> coworkers = getCoworkersOfThisProject(projectId);
            return new Project(projectId, title, managerId, coworkers, chatroomIds, createdAt);
        }

        return null;
    }

    public Project getProject(int id) throws SQLException {
        CheckConnection();
        String sql = "SELECT * FROM project LEFT JOIN projectHasChatrooms "
                + "ON project.id = projectHasChatrooms.projectId "
                + "WHERE id = " + id + "";

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();

        ArrayList<Integer> chatroomIds = new ArrayList<>();
        if (resultSet != null && resultSet.getString(1) != null) {
            int projectId = resultSet.getInt("id");
            String title = resultSet.getString("title");
            int managerId = resultSet.getInt("managerId");
            String createdAt = resultSet.getString("createdAt");

            while (resultSet.next()) {
                chatroomIds.add(resultSet.getInt("chatroomId"));
            }
            ArrayList<Person> coworkers = getCoworkersOfThisProject(projectId);
            return new Project(projectId, title, managerId, coworkers, chatroomIds, createdAt);
        }

        return null;
    }

    public ArrayList<Person> getCoworkersOfThisProject(int projectId) throws SQLException {
        CheckConnection();
        String sql = "SELECT * from people LEFT JOIN projectHasPeople "
                + " ON people.id = projectHasPeople.personId "
                + " WHERE projectId =" + projectId + "";

        ArrayList<Person> workers = new ArrayList<>();
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();

        if(resultSet.isClosed()){
            return  workers;
        }
        
        if (resultSet != null && resultSet.getString("username") != null) {
            while (resultSet.next()) {
                workers.add(new Person(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("username"),
                        byteArrayToImageIcon(resultSet.getBytes(5))));
            }
        }

        return workers;
    }

    public Chatroom getChatroom(String title) throws SQLException {
        CheckConnection();
        String sql = "select * from chatroom where title ='" + title + "'";

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet != null && resultSet.getString(1) != null) {

            return new Chatroom(resultSet.getInt("id"),
                    resultSet.getString("title"),
                    resultSet.getInt("managerId"));
        }

        return null;
    }

    public boolean CreateChatroom(String title, int managerId) throws SQLException {
        CheckConnection();
        String sql = "INSERT INTO chatroom (title, managerId) values (?,?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);

        preparedStatement.setString(1, title);
        preparedStatement.setInt(2, managerId);

        preparedStatement.execute();

        return true;
    }

    public boolean CreateChatroom(String title, int managerId, int projectId) throws SQLException {

        CreateChatroom(title, managerId);
        Chatroom room = getChatroom(title);
        if (projectId != -1) {
            AddChatroomToProject(projectId, room.getId());
        }
        AddPersonToChatroom(room.getId(), managerId);

        return true;
    }

    public boolean CreateProject(String title, int managerId) throws SQLException {
        CheckConnection();
        //Create main Chatroom
        String chatTitle = "Project " + title + " Main Chatroom";
        CreateChatroom(chatTitle, managerId);
        Chatroom mainChatroom = getChatroom(chatTitle);

        //Create project
        String sql = "INSERT INTO project (title,managerId) values (?,?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);

        preparedStatement.setString(1, title);
        preparedStatement.setInt(2, managerId);

        preparedStatement.execute();

        Project P = getProject(title);

        //Adding information to tables
        AddPersonToProject(P.getId(), managerId);
        AddChatroomToProject(P.getId(), mainChatroom.getId());
        AddPersonToChatroom(mainChatroom.getId(), managerId);
        return true;
    }

    public boolean AddPersonToProject(int projectId, int personId) throws SQLException {
        CheckConnection();

        String sql = "INSERT INTO projectHasPeople (projectId,personId) values (?,?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);

        preparedStatement.setInt(1, projectId);
        preparedStatement.setInt(2, personId);
        preparedStatement.execute();
        return true;
    }

    public boolean AddChatroomToProject(int projectId, int chatRoomId) throws SQLException {
        CheckConnection();

        String sql = "INSERT INTO projectHasChatrooms (projectId,chatroomId) values (?,?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);

        preparedStatement.setInt(1, projectId);
        preparedStatement.setInt(2, chatRoomId);
        preparedStatement.execute();
        return true;
    }

    public boolean AddPersonToChatroom(int chatroomId, int personId) throws SQLException {
        CheckConnection();

        String sql = "INSERT INTO chatroomHasPeople (chatroomId,personId) values (?,?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);

        preparedStatement.setInt(1, chatroomId);
        preparedStatement.setInt(2, personId);
        preparedStatement.execute();
        return true;
    }

    ArrayList<Chatroom> getChatroomsOfThis(Person person) throws SQLException {
        //TO DO
        //search in "project has people and projects"
        return getChatroomsOfThis(person.getId());
    }
    
    ArrayList<Chatroom> getChatroomsOfThis(int personId) throws SQLException{
        
        CheckConnection();

        String sql = "SELECT * from chatroom LEFT JOIN chatroomHasPeople ON chatroom.id=chatroomHasPeople.chatroomId where personId = '" + personId + "'";

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();

        ArrayList<Chatroom> chatrooms = new ArrayList<>();
        while (resultSet.next()) {
            chatrooms.add(new Chatroom(resultSet.getInt(1),
                    resultSet.getString("title"),
                    resultSet.getInt("managerId"))
            );
        }

        return chatrooms;
    }

    public boolean CreateFriendShip(int id1, int id2) throws SQLException {
        CheckConnection();

        if (!isPersonExist(id2)) {
            return false;
        }

        //person1's id always should be bigger than second one so there won't be same friendships
        if (id1 < id2) {
            int temp = id1;
            id1 = id2;
            id2 = temp;
        }

        if (isFriendShipExistBetween(id1, id2)) {
            return false;
        }

        String chatRoomTitle = id1 + ":" + id2;
        CreateChatroom(chatRoomTitle, -1);
        Chatroom chatroom = getChatroom(chatRoomTitle);

        String sql = "INSERT INTO friendship (chatroomId, person1Id, person2Id) VALUES (?,?,?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);

        preparedStatement.setInt(1, chatroom.getId());
        preparedStatement.setInt(2, id1);
        preparedStatement.setInt(3, id2);
        preparedStatement.execute();

        return true;
    }

    boolean isFriendShipExistBetween(int id1, int id2) throws SQLException {

        //person1's id always should be bigger than second one so there won't be same friendships
        if (id1 < id2) {
            int temp = id1;
            id1 = id2;
            id2 = temp;
        }

        String sql = "SELECT * FROM friendship "
                + " WHERE person1Id = " + id1 + ""
                + " AND person2Id = " + id2;
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet == null) {
            return false;
        }

        if (resultSet.isClosed()) {
            return false;
        }

        if (resultSet.getString(1) == null) {
            return false;
        }

        return true;
    }

    ArrayList<FriendShip> getFriendShipsOfThis(int personId) throws SQLException {
        CheckConnection();

        //if first person
        String sql = "SELECT * FROM friendship , people p "
                + " WHERE p.id = " + personId
                + " AND (person1Id = p.id "
                + " OR person2Id = p.id)";

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();

        System.out.println(resultSet.toString());
        ArrayList<FriendShip> friendShips = new ArrayList<>();
        while (resultSet.next()) {

            Person person2;
            int id1 = resultSet.getInt("person1Id");
            int id2 = resultSet.getInt("person2Id");
            int peopleId = personId;

            int chatroomId = resultSet.getInt("chatroomId");

            if (peopleId == id1) {
                person2 = getPerson(id2);
            } else {
                person2 = getPerson(id1);
            }

            friendShips.add(
                    new FriendShip(person2, new Chatroom(chatroomId))
            );
        }

        return friendShips;
    }

    Person getPerson(int id) {
        CheckConnection();
        String sql = "SELECT * FROM people WHERE id =" + id;

        try {
            PreparedStatement preparedStatement2 = connection.prepareStatement(sql);
            ResultSet resultSet2 = preparedStatement2.executeQuery();

            if (resultSet2 != null && resultSet2.getString(1) != null) {

                return new Person(
                        resultSet2.getInt("id"),
                        resultSet2.getString("name"),
                        resultSet2.getString("username"),
                        byteArrayToImageIcon(resultSet2.getBytes(5)));
            }

        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }

        return null;
    }

    boolean JoinProject(int personId, int projectId) throws SQLException {
        CheckConnection();

        if (!isProjectExist(projectId)) {
            return false;
        }

        if (isPersonExistInProject(personId, projectId)) {
            return false;
        }

        AddPersonToProject(projectId, personId);

        return true;
    }

    boolean isPersonExistInProject(int personId, int projectId) throws SQLException {
        CheckConnection();
        String sql = "SELECT * FROM projectHasPeople "
                + " WHERE projectId =" + projectId
                + " AND personId = " + personId;

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet == null) {
            return false;
        }

        if (resultSet.isClosed()) {
            return false;
        }

        if (resultSet.getString(1) == null) {
            return false;
        }

        return true;
    }

    boolean isProjectExist(int projectId) throws SQLException {
        CheckConnection();
        String sql = "SELECT * FROM project WHERE id = " + projectId;

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet == null) {
            return false;
        }

        if (resultSet.isClosed()) {
            return false;
        }

        if (resultSet.getString(1) == null) {
            return false;
        }

        return true;
    }

    public int getMainChatroomId(int projectId) throws SQLException {
        CheckConnection();
        String sql = "SELECT chatroomId FROM projectHasChatrooms "
                + " WHERE projectId = " + projectId
                + " ORDER BY chatroomId ASC";

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet != null && resultSet.getString(1) != null) {
            return resultSet.getInt("chatroomId");
        }

        return -1;
    }

    boolean AddFriendToChatroom(Integer friendId, Integer chatroomId) throws SQLException {
        CheckConnection();

        if (isPersonExistInChatroom(friendId, chatroomId)) {
            return false;
        }

        AddPersonToChatroom(chatroomId, friendId);

        return true;
    }

    private boolean isPersonExistInChatroom(Integer friendId, Integer chatroomId) throws SQLException {
        CheckConnection();
        String sql = "SELECT * FROM chatroomHasPeople "
                + " WHERE chatroomId =" + chatroomId
                + " AND personId = " + friendId;

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet == null) {
            return false;
        }
        
        if (resultSet.isClosed()) {
            return false;
        }

        if (resultSet.getString(1) == null) {
            return false;
        }

        return true;
    }

    private boolean isPersonExist(int id) throws SQLException {
        CheckConnection();
        String sql = "SELECT * FROM people "
                + " WHERE id =" + id;

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet == null) {
            return false;
        }
        
        if (resultSet.isClosed()) {
            return false;
        }

        if (resultSet.getString(1) == null) {
            return false;
        }

        return true;
    }

    public boolean CreateChatMessage(ChatMessage message) throws SQLException {
        CheckConnection();
        String sql = "INSERT INTO message (senderId,chatroomId,content,date) VALUES (?,?,?,?)";

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1, message.getSenderId());
        preparedStatement.setInt(2, message.getChatroomId());
        preparedStatement.setString(3, message.getContent());
        preparedStatement.setString(4, message.getSendAt());

        preparedStatement.execute();

        return true;
    }

    public ArrayList<ChatMessage> getChatMessagesOfThisRoom(int chatroomId) throws SQLException {
        CheckConnection();
        //no need to check if chatroom exist because only they can send message that exist a chatroom

        String sql = "SELECT * FROM message LEFT JOIN messageHasFile "
                + " ON id = messageId "
                + " WHERE chatroomId = " + chatroomId
                + " ORDER BY date ASC";

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();

        ArrayList<ChatMessage> messages = new ArrayList<>();
        while (resultSet.next()) {
            if (resultSet.getString("fileName") == null) {
                messages.add(new ChatMessage(resultSet.getInt("senderId"), chatroomId, resultSet.getString("content"), resultSet.getString("date")));
            } else {
                messages.add(new ChatMessageWithFile(resultSet.getInt("senderId"),
                        chatroomId,
                        resultSet.getString("content"),
                        resultSet.getString("date"),
                        resultSet.getBytes("file"),
                        resultSet.getString("fileName")));
            }

        }

        return messages;
    }

    ArrayList<Person> getPeopleOfThisRoom(int chatroomId) throws SQLException {
        CheckConnection();
        //no need to check if chatroom exist because only they can send message that exist a chatroom

        String sql = "SELECT * FROM people LEFT JOIN chatroomHasPeople "
                + " ON people.id = chatroomHasPeople.personId "
                + " WHERE chatroomId = " + chatroomId;

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();

        ArrayList<Person> people = new ArrayList<>();
        while (resultSet.next()) {
            people.add(new Person(
                    resultSet.getInt("id"),
                    resultSet.getString("name"),
                    resultSet.getString("username"),
                    byteArrayToImageIcon(resultSet.getBytes(5))));
        }

        sql = "SELECT * FROM people LEFT JOIN friendship "
                + " ON people.id = friendship.person1Id"
                + " OR people.id = friendship.person2Id"
                + " WHERE chatroomId = " + chatroomId;

        preparedStatement = connection.prepareStatement(sql);
        resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            people.add(new Person(
                    resultSet.getInt("id"),
                    resultSet.getString("name"),
                    resultSet.getString("username"),
                    byteArrayToImageIcon(resultSet.getBytes(5))));
        }

        return people;
    }

    boolean CreateChatMessageWithFile(ChatMessageWithFile chatMessage) throws SQLException {
        CheckConnection();
        String sql = "INSERT INTO message (senderId,chatroomId,content,date) VALUES (?,?,?,?)";

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1, chatMessage.getSenderId());
        preparedStatement.setInt(2, chatMessage.getChatroomId());
        preparedStatement.setString(3, chatMessage.getContent());
        preparedStatement.setString(4, chatMessage.getSendAt());
        preparedStatement.execute();
        System.out.println("Message Created");

        sql = "INSERT INTO messageHasFile (messageId, fileName, file) VALUES (?,?,?)";
        PreparedStatement secondPreparedStatement = connection.prepareStatement(sql);
        secondPreparedStatement.setInt(1, getMessageId(chatMessage));
        secondPreparedStatement.setString(2, chatMessage.getFileName());
        secondPreparedStatement.setBytes(3, chatMessage.getFileContent());
        secondPreparedStatement.execute();
        System.out.println("File message Created");

        return true;
    }

    int getMessageId(ChatMessage chatMessage) throws SQLException {
        CheckConnection();

        String sql = "SELECT id FROM message "
                + " WHERE senderId =" + chatMessage.getSenderId()
                + " AND chatroomId =" + chatMessage.getChatroomId()
                + " AND content = '" + chatMessage.getContent() + "'"
                + " AND date = '" + chatMessage.getSendAt() + "'";

        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();

        return resultSet.getInt("id");
    }

    ArrayList<Integer> getPeopleIdsOfThisProject(int projectId) throws SQLException {
        CheckConnection();
        String sql = "SELECT personId FROM projectHasPeople where projectId =" + projectId;

        ArrayList<Integer> peopleIds = new ArrayList<>();
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();
        
        while (resultSet.next()) {            
            peopleIds.add(resultSet.getInt("personId"));
        }

        return peopleIds;
    }
}
