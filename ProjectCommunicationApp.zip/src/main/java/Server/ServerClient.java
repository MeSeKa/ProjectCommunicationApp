package Server;

import Models.*;
import NetworkModels.LoginInformation;
import NetworkModels.Message;
import NetworkModels.MessageType;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ServerClient extends Thread {

    // her clientın bir soketi olamlı
    public Socket socket;
    private MainServer server;

    // gönderilecek alınacak bilgileri byte dizisine çevirmek için
    private ObjectInputStream sInput;
    //private DataInputStream sInput;
    private ObjectOutputStream sOutput;

    public boolean isListening;

    private int personId;

    public int getPersonId() {
        return personId;
    }

    //yapıcı metod
    public ServerClient(MainServer server, Socket clientSocket) {

        try {
            this.socket = clientSocket;
            sInput = new ObjectInputStream(new DataInputStream(clientSocket.getInputStream()));
            sOutput = new ObjectOutputStream(new DataOutputStream(clientSocket.getOutputStream()));
            this.server = server;
        } catch (IOException ex) {
            Logger.getLogger(ServerClient.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void Listen() {
        this.isListening = true;
        this.start();
    }

    @Override
    public void run() {
        try {
            while (this.isListening) {
                HandleMessage();
            }

        } catch (IOException ex) {
            Logger.getLogger(ServerClient.class.getName()).log(Level.SEVERE, null, ex);
            this.Disconnect();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ServerClient.class.getName()).log(Level.SEVERE, null, ex);
            this.Disconnect();
        }

        System.out.println("Server Client Thread Finished");
    }

    //clientı kapatan fonksiyon
    public void Disconnect() {
        try {
            this.isListening = false;
            this.socket.close();
            this.sInput.close();
            this.sOutput.close();
            this.server.DisconnectClient(this);

        } catch (IOException ex) {
            Logger.getLogger(ServerClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    void HandleMessage() throws IOException, ClassNotFoundException {
        Message message = (Message) sInput.readObject();

        switch (message.getMessageType()) {
            case LoginInformation:
                Login(socket, message);
                break;
            case RegisterInformation:
                Register(socket, message);
                break;
            case CreateProject:
                CreateProject(message);
                break;
            case CreateChatroom:
                CreateChatroom(message);
                break;
            case CreateFriendShip:
                CreateFriendShip(message);
                break;
            case RequestProjects:
                RequestProjects(message);
                break;
            case RequestChatrooms:
                RequestChatrooms(message);
                break;
            case RequestFriendShips:
                RequestFriendShips(message);
                break;
            case JoinProject:
                JoinProject(message);
                break;
            case AddFriendToChatroom:
                AddFriendToChatroom(message);
                break;
            case MessageWithFile:
                CreateChatMessageWithFile(message);
                break;
            case RequestAllChatroomMessages:
                RequestAllChatroomMessages(message);
                break;
            case RequestAllFriendShipMessages:
                RequestAllFriendShipMessages(message);
                break;
            case SingleChatMessage:
                CreateSingleChatMessage(message);
                break;
            default:
                throw new AssertionError();
        }

    }

    void Login(Socket clientSocket, Message message) throws IOException {
        //Check if the person exist in person list
        LoginInformation loginInformation = (LoginInformation) message.getContent();
        Person person = Database.Instance().getPerson(loginInformation.getUserName(), loginInformation.getPassword());

        //if exist then create a thread for it and send a positive signal
        if (person != null) {
            System.out.println(loginInformation.getUserName() + " connected");
            sOutput.writeObject(new Message(MessageType.Person, person));

            this.personId = person.getId();

        } else {
            //if not exist then send a negative signal and then wait for new connection
            sOutput.writeObject(new Message(MessageType.Wrong, "The informaton that you gave is not matched anyone in database"));
            System.out.println(loginInformation.getUserName() + " not connected");
        }
    }

    void Register(Socket clientSocket, Message message) throws IOException {
        //Check if the person exist in person list
        Person person = (Person) message.getContent();

        try {
            //Try to add person to the database
            if (Database.Instance().CreatePerson(person)) {
                message = new Message(MessageType.Approve, MessageType.RegisterInformation);
                System.out.println("SUCCESFULLY REGISTERED");
                sOutput.writeObject(message);
            }
        } catch (SQLException ex) {
            Logger.getLogger(MainServer.class.getName()).log(Level.SEVERE, null, ex);
            message = new Message(MessageType.Wrong, ex.toString());
            sOutput.writeObject(message);
            this.Disconnect();
        }

        this.Disconnect();
    }

    void CreateProject(Message message) throws IOException {
        Project project = (Project) message.getContent();

        try {
            //Try to add person to the database
            if (Database.Instance().CreateProject(project.getTitle(), project.getManagerId())) {
                message = new Message(MessageType.Approve, MessageType.CreateProject);
                sOutput.writeObject(message);
            }
        } catch (SQLException ex) {
            Logger.getLogger(MainServer.class.getName()).log(Level.SEVERE, null, ex);
            message = new Message(MessageType.Wrong, MessageType.CreateProject + "\n" + ex.toString());
            sOutput.writeObject(message);
        }
    }

    private void CreateChatroom(Message message) throws IOException {
        Chatroom room = (Chatroom) message.getContent();

        try {

            if (Database.Instance().CreateChatroom(room.getTitle(), room.getManagerId(), room.getId())) {
                message = new Message(MessageType.Approve, MessageType.CreateChatroom);
                sOutput.writeObject(message);
            }
        } catch (SQLException ex) {
            Logger.getLogger(MainServer.class.getName()).log(Level.SEVERE, null, ex);
            message = new Message(MessageType.Wrong, MessageType.CreateChatroom + "\n" + ex.toString());
            sOutput.writeObject(message);
        }
    }

    void RequestProjects(Message message) throws IOException {
        Person person = (Person) message.getContent();
        RequestProjects(person.getId());

    }

    void RequestProjects(int personId) throws IOException {

        try {
            //Try to add person to the database
            ArrayList<Project> projects = Database.Instance().getProjectsOfThis(personId);
            Message message = new Message(MessageType.RequestProjects, projects);
            sOutput.writeObject(message);

        } catch (SQLException ex) {
            Logger.getLogger(MainServer.class.getName()).log(Level.SEVERE, null, ex);
            Message message = new Message(MessageType.Wrong, MessageType.RequestProjects + "\n" + ex.toString());
            sOutput.writeObject(message);
        }
    }

    private void CreateFriendShip(Message message) throws IOException {
        int newFriendId = (int) ((Integer) message.getContent());

        try {

            if (Database.Instance().CreateFriendShip(this.personId, newFriendId)) {
                message = new Message(MessageType.Approve, MessageType.CreateFriendShip);
                sOutput.writeObject(message);
                InformOtherFriend(newFriendId);
            } else {
                message = new Message(MessageType.Wrong, MessageType.CreateFriendShip + "\nFriendship already exist or the person you are try'ng to add as a friend not exist");
                sOutput.writeObject(message);
            }
        } catch (SQLException ex) {
            Logger.getLogger(MainServer.class.getName()).log(Level.SEVERE, null, ex);
            message = new Message(MessageType.Wrong, ex.toString());
            sOutput.writeObject(message);
        }
    }

    public void RequestFriendShips(Message message) throws IOException {
        Person person = (Person) message.getContent();

        RequestFriendShips(person.getId());
    }

    public void RequestFriendShips(int personId) throws IOException {

        try {
            //Try to add person to the database
            ArrayList<FriendShip> friendShips = Database.Instance().getFriendShipsOfThis(personId);
            Message message = new Message(MessageType.RequestFriendShips, friendShips);
            sOutput.writeObject(message);

        } catch (SQLException ex) {
            Logger.getLogger(MainServer.class.getName()).log(Level.SEVERE, null, ex);
            Message message = new Message(MessageType.Wrong, MessageType.RequestFriendShips + "\n" + ex.toString());
            sOutput.writeObject(message);
        }
    }

    private void JoinProject(Message message) throws IOException {
        int projectId = (int) ((Integer) message.getContent());

        try {

            if (Database.Instance().JoinProject(this.personId, projectId)) {
                
                int mainChatRoomId = Database.Instance().getMainChatroomId(projectId);
                Database.Instance().AddPersonToChatroom(mainChatRoomId, personId);
                ArrayList<Person> people = Database.Instance().getPeopleOfThisRoom(mainChatRoomId);
                server.InformOtherChatroomMembers(people);
                
                message = new Message(MessageType.Approve, MessageType.JoinProject + "\nSuccesfully joined to project");
                sOutput.writeObject(message);

                ArrayList<Integer> peopleIds = Database.Instance().getPeopleIdsOfThisProject(projectId);
                server.InformOtherProjectMembers(peopleIds);

            } else {
                message = new Message(MessageType.Wrong, MessageType.JoinProject + "\nProject is not exist in the database, or the person you are trying to add is already exist in the project");
                sOutput.writeObject(message);
            }
        } catch (SQLException ex) {
            Logger.getLogger(MainServer.class.getName()).log(Level.SEVERE, null, ex);
            message = new Message(MessageType.Wrong, ex.toString());
            sOutput.writeObject(message);
        }
    }

    private void AddFriendToChatroom(Message message) throws IOException {
        ArrayList<Integer> friendAndChatroom;
        friendAndChatroom = (ArrayList<Integer>) message.getContent();

        try {

            if (Database.Instance().AddFriendToChatroom(friendAndChatroom.get(0), friendAndChatroom.get(1))) {
                message = new Message(MessageType.Approve, MessageType.AddFriendToChatroom + "\nSuccesfully added friend to chatroom");
                sOutput.writeObject(message);
                server.InformOtherFriendForAddingNewChatroom(friendAndChatroom.get(0));
            } else {
                message = new Message(MessageType.Wrong, MessageType.AddFriendToChatroom + "\nFriend already exist in the room");
                sOutput.writeObject(message);
            }
        } catch (SQLException ex) {
            Logger.getLogger(MainServer.class.getName()).log(Level.SEVERE, null, ex);
            message = new Message(MessageType.Wrong, MessageType.AddFriendToChatroom + "\n" + ex.toString());
            sOutput.writeObject(message);
        }
    }

    private void CreateSingleChatMessage(Message message) throws IOException {
        ChatMessage chatMessage = (ChatMessage) message.getContent();

        try {
            if (Database.Instance().CreateChatMessage(chatMessage)) {
                server.SendMessageToClients(chatMessage);

            } else {
                message = new Message(MessageType.Wrong, MessageType.CreateMessage + "\nMessage could't add to database");
                sOutput.writeObject(message);
            }
        } catch (SQLException ex) {
            Logger.getLogger(MainServer.class.getName()).log(Level.SEVERE, null, ex);
            message = new Message(MessageType.Wrong, MessageType.CreateMessage + "\n" + ex.toString());
            sOutput.writeObject(message);
        }
    }

    public void SendMessageToClient(ChatMessage chatMessage) throws IOException {
        Message messageToSend;
        if (chatMessage instanceof ChatMessageWithFile) {
            messageToSend = new Message(MessageType.MessageWithFile, chatMessage);
        } else {
            messageToSend = new Message(MessageType.SingleChatMessage, chatMessage);
        }
        sOutput.writeObject(messageToSend);

    }

    private void RequestAllChatroomMessages(Message message) throws IOException {
        ArrayList<Chatroom> rooms = (ArrayList<Chatroom>) message.getContent();

        try {
            //Try to add person to the database
            for (Chatroom room : rooms) {
                room.setMessages(Database.Instance().getChatMessagesOfThisRoom(room.getId()));
                room.setPeople(Database.Instance().getPeopleOfThisRoom(room.getId()));
            }

            message = new Message(MessageType.RequestAllChatroomMessages, rooms);
            sOutput.writeObject(message);

        } catch (SQLException ex) {
            Logger.getLogger(MainServer.class.getName()).log(Level.SEVERE, null, ex);
            message = new Message(MessageType.Wrong, MessageType.RequestAllChatroomMessages + "\n" + ex.toString());
            sOutput.writeObject(message);
        }
    }

    private void RequestAllFriendShipMessages(Message message) throws IOException {
        ArrayList<FriendShip> friendShips = (ArrayList<FriendShip>) message.getContent();

        try {
            //Try to add person to the database
            for (FriendShip friendShip : friendShips) {
                Chatroom room = friendShip.getChatroom();
                room.setMessages(Database.Instance().getChatMessagesOfThisRoom(room.getId()));

                ArrayList<Person> people = new ArrayList<>();
                people.add(Database.Instance().getPerson(this.personId));
                people.add((friendShip.getPerson()));
                room.setPeople(people);
            }

            message = new Message(MessageType.RequestAllFriendShipMessages, friendShips);
            sOutput.writeObject(message);

        } catch (SQLException ex) {
            Logger.getLogger(MainServer.class.getName()).log(Level.SEVERE, null, ex);
            message = new Message(MessageType.Wrong, MessageType.RequestAllFriendShipMessages + "\n" + ex.toString());
            sOutput.writeObject(message);
        }
    }

    private void InformOtherFriend(int friendId) throws IOException {
        server.InformOtherFriend(friendId);
    }

    private void CreateChatMessageWithFile(Message message) throws IOException {
        ChatMessageWithFile chatMessage = (ChatMessageWithFile) message.getContent();

        try {
            if (Database.Instance().CreateChatMessageWithFile(chatMessage)) {
                server.SendMessageToClients(chatMessage);

            } else {
                message = new Message(MessageType.Wrong, MessageType.CreateMessage + "\nMessage could't add to database");
                sOutput.writeObject(message);
            }
        } catch (SQLException ex) {
            Logger.getLogger(MainServer.class.getName()).log(Level.SEVERE, null, ex);
            message = new Message(MessageType.Wrong, MessageType.CreateMessage + "\n" + ex.toString());
            sOutput.writeObject(message);
        }
    }

    void RequestChatrooms(int personId) throws IOException {

        try {
            //Try to add person to the database
            ArrayList<Chatroom> chatrooms = Database.Instance().getChatroomsOfThis(personId);
            Message message = new Message(MessageType.RequestChatrooms, chatrooms);
            sOutput.writeObject(message);

        } catch (SQLException ex) {
            Logger.getLogger(MainServer.class.getName()).log(Level.SEVERE, null, ex);
            Message message = new Message(MessageType.Wrong, MessageType.RequestChatrooms + "\n" + ex.toString());
            sOutput.writeObject(message);
        }
    }

    private void RequestChatrooms(Message message) throws IOException {
        Person person = (Person) message.getContent();
        RequestChatrooms(person.getId());
    }
}
