package Server;

import Models.ChatMessage;
import Models.Person;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MainServer extends Thread {

    ServerSocket serverSocket;
    int port;

    ObjectOutputStream sOutput;
    ObjectInputStream sInput;

    ArrayList<ServerClient> clientList;

    boolean isRunning;

    void startServer(String ip, int port) {
        try {
            this.port = port;
            serverSocket = new ServerSocket(port);

            clientList = new ArrayList<>();
            isRunning = true;

        } catch (IOException ex) {
            System.out.println("CANNOT CREATE SERVER");
            Logger.getLogger(MainServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void run() {

        try {
            while (isRunning) {
                //When new connection occured
                System.out.println("Waiting a client to connect");
                Socket clientSocket = this.serverSocket.accept();//blocing

                ServerClient newServerClient = new ServerClient(this, clientSocket);
                newServerClient.Listen();

                clientList.add(newServerClient);
            }
        } catch (IOException ex) {
            Logger.getLogger(MainServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void DisconnectClient(ServerClient client) {
        this.clientList.remove(client);
    }

    public void DisconnectelectedClient(int index) {
        clientList.get(index).Disconnect();
    }

    public void SendMessageToClients(ChatMessage messageToSend) throws SQLException, IOException {
        //TODO 
        //Search chatroom has person and find the people that insides in that chatroom
        //check if their ids are in the serverclientList's 
        //if exist then send the chatmessage to this client
        ArrayList<Person> peopleOfThatChatroom
                = Database.Instance().getPeopleOfThisRoom(messageToSend.getChatroomId());

        for (Person person : peopleOfThatChatroom) {
            for (ServerClient serverClient : clientList) {
                if (person.getId() == serverClient.getPersonId()) {
                    serverClient.SendMessageToClient(messageToSend);
                    break;
                }
            }
        }

    }

    public void InformOtherFriend(int friendId) throws IOException {
        for (ServerClient serverClient : clientList) {
            if (friendId == serverClient.getPersonId()) {
                serverClient.RequestFriendShips(friendId);
            }
        }
    }
    
    public void InformOtherFriendForAddingNewChatroom(int friendId) throws IOException {
        for (ServerClient serverClient : clientList) {
            if (friendId == serverClient.getPersonId()) {
                serverClient.RequestChatrooms(friendId);
                break;
            }
        }
    }

    public void InformOtherProjectMembers(ArrayList<Integer> peopleIds) throws IOException {
        for (ServerClient serverClient : clientList) {
            for (Integer peopleId : peopleIds) {
                if (peopleId == serverClient.getPersonId()) {
                    serverClient.RequestProjects(peopleId);
                    break;
                }
            }
        }
    }
    
    public void InformOtherChatroomMembersIds(ArrayList<Integer> peopleIds) throws IOException {
        for (ServerClient serverClient : clientList) {
            for (Integer peopleId : peopleIds) {
                if (peopleId == serverClient.getPersonId()) {
                    serverClient.RequestChatrooms(peopleId);
                    break;
                }
            }
        }
    }
    
    public void InformOtherChatroomMembers(ArrayList<Person> people) throws IOException {
        ArrayList<Integer> peopleIds = new ArrayList<>();
        for (Person person : people) {
            peopleIds.add(person.getId());
        }
        InformOtherChatroomMembersIds(peopleIds);
    }
    
}
