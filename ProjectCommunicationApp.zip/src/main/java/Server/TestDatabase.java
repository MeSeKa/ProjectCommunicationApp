package Server;

import Models.ChatMessageWithFile;
import com.vdurmont.emoji.EmojiParser;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.ImageIcon;

/**
 *
 * @author Mehmed Sefa
 */
public class TestDatabase {

    public static void main(String[] args) {
        //Database.Instance().getPerson("meseka", "123");

        String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
        System.out.println(timeStamp);

        String fileName = "whatIsMyExtension.java";

        System.out.println(ChatMessageWithFile.getExtension(fileName));

//        String str = "An :grinning:awesome :smiley:string &#128516;with a few :wink:emojis!";
//        String result = EmojiParser.parseToUnicode(str);
//        System.out.println(result);
        String str = "Here is a boy: \uD83D\uDC66\uD83C\uDFFF!";
        System.out.println(EmojiParser.parseToAliases(str));
    }
}
