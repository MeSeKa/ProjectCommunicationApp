/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUIModels;

import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 *
 * @author Mehmed Sefa
 */
public class IconListItem {
        private ImageIcon icon;
        private String text;
        private int id;

        public IconListItem(ImageIcon icon, String text, int id) {
            
            Image img = icon.getImage();
            Image imgScale = img.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
            ImageIcon scaledImage = new ImageIcon(imgScale);
            
            
            this.icon = scaledImage;
            this.text = text;
            this.id = id;
        }

        public Icon getIcon() {
            return icon;
        }

        public String getText() {
            return text;
        }

    public int getId() {
        return id;
    }
        
        
    }
