package GUIModels;

/**
 *
 * @author Mehmed Sefa
 */
import Client.ClientFrame;
import Models.FriendShip;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class IconList extends JPanel {

    private int iconSize = 50;

    private DefaultListModel<IconListItem> listModel;
    private JList<IconListItem> iconList;

    ClientFrame clientFrame;

    public IconList(ClientFrame clientFrame) {
    this.clientFrame = clientFrame;
    // Panelin layoutunu ayarla
    setLayout(new BorderLayout());
    
    // Liste modelini oluştur
    listModel = new DefaultListModel<>();
    iconList = new JList<>(listModel);
    
    // Liste görünümünü özelleştir
    iconList.setCellRenderer(new IconListRenderer());
    
    // Liste panele ekle
    JScrollPane scrollPane = new JScrollPane(iconList);
    add(scrollPane, BorderLayout.CENTER);
    
    // Listede bir öğe seçildiğinde olay dinleyici ekle
    iconList.addListSelectionListener(new ListSelectionListener() {
        public void valueChanged(ListSelectionEvent e) {
            if (!e.getValueIsAdjusting()) {
                // Seçilen öğeyi al
                IconListItem selectedItem = iconList.getSelectedValue();
                if (selectedItem != null) {
                    clientFrame.SelectFriend(selectedItem.getId());
                }
            }
        }
    });
}


    // Liste öğesi ekleme metodu
    public void addListItem(ImageIcon icon, String text, int id) {
        listModel.addElement(new IconListItem(icon, text, id));
        iconList.setFixedCellHeight(iconSize + 10);
    }

    public void UpdateIconList(ArrayList<FriendShip> friendShips) {
    // Mevcut liste modelini temizle
    listModel.clear();

    // Liste öğelerini ekle
    for (FriendShip friendAndChatroom : friendShips) {
        addListItem(friendAndChatroom.getPerson().getIcon(), friendAndChatroom.getPerson().getName(), friendAndChatroom.getPerson().getId());
    }
}


    // Liste öğesi için özel bir hücre renderleyici sınıfı
    private class IconListRenderer extends DefaultListCellRenderer {

        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            JPanel panel = new JPanel();
            panel.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));

            IconListItem item = (IconListItem) value;

            // Simgeyi ekle
            JLabel iconLabel = new JLabel(item.getIcon());
            panel.add(iconLabel);

            // İsmi ekle
            JLabel textLabel = new JLabel(item.getText());
            panel.add(textLabel);

            // Seçilen öğenin arka planını değiştir
            if (isSelected) {
                panel.setBackground(Color.lightGray);
            } else {
                panel.setBackground(Color.white);
            }

            // Seçilen öğenin etrafına bir border ekle
            if (cellHasFocus) {
                panel.setBorder(BorderFactory.createLineBorder(Color.black));
            } else {
                panel.setBorder(BorderFactory.createEmptyBorder());
            }

            return panel;
        }

    }
}
