package GUIModels;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import Models.ChatMessage;
import Models.ChatMessageWithFile;
import Models.Chatroom;
import Models.Person;
import com.vdurmont.emoji.EmojiParser;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.filechooser.FileSystemView;

class ChatMessageRenderer extends JComponent implements ListCellRenderer<ChatMessage> {

    private JLabel senderLabel;
    private JTextArea contentArea;
    private JLabel dateLabel;
    private JLabel iconLabel;
    private ArrayList<Person> people;
    private int thisPersonId;
    private int iconSize = 35;

    private JButton fileButton;

    public ChatMessageRenderer(ArrayList<Person> people, int thisPersonId) {

        this.people = people;
        this.thisPersonId = thisPersonId;
        setLayout(new BorderLayout());

        senderLabel = new JLabel();
        add(senderLabel, BorderLayout.NORTH);

        iconLabel = new JLabel();
        add(iconLabel, BorderLayout.WEST);

        contentArea = new JTextArea();
        contentArea.setLineWrap(true);
        contentArea.setWrapStyleWord(true);
        contentArea.setEditable(false);

        dateLabel = new JLabel();
        dateLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        dateLabel.setVerticalAlignment(SwingConstants.BOTTOM);

        fileButton = new JButton();
        fileButton.setHorizontalAlignment(SwingConstants.LEFT);
        fileButton.setVerticalAlignment(SwingConstants.BOTTOM);
        fileButton.setEnabled(true);

        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.add(fileButton, BorderLayout.NORTH);
        contentPanel.add(contentArea, BorderLayout.CENTER);
        contentPanel.add(dateLabel, BorderLayout.SOUTH);

        JScrollPane contentScrollPane = new JScrollPane(contentPanel);
        contentScrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        contentScrollPane.setPreferredSize(new Dimension(250, 100)); // Set your preferred size here
        add(contentScrollPane, BorderLayout.CENTER);
    }

    @Override
    public Component getListCellRendererComponent(JList<? extends ChatMessage> list, ChatMessage value, int index, boolean isSelected, boolean cellHasFocus) {

        contentArea.setText(EmojiParser.parseToUnicode(EmojiParser.parseToAliases(value.getContent())));
        dateLabel.setText(value.getSendAt());

        // Retrieve the sender's icon from the list of people
        ImageIcon senderIcon = null;
        for (Person person : people) {
            if (person.getId() == (value.getSenderId())) {
                senderIcon = person.getIcon();
                senderLabel.setText(person.getName());
                break;
            }
        }

        Image img = senderIcon.getImage();
        Image imgScale = img.getScaledInstance(iconSize, iconSize, Image.SCALE_SMOOTH);
        ImageIcon scaledImage = new ImageIcon(imgScale);

        // Check if the message sender is the same as this person
        boolean isSameSender = value.getSenderId() == thisPersonId;

        if (isSameSender) {
            contentArea.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, iconSize + 5));
            iconLabel.setIcon(scaledImage);
            add(iconLabel, BorderLayout.EAST);
            senderLabel.setText("You");
        } else {
            contentArea.setBorder(BorderFactory.createEmptyBorder(5, iconSize + 5, 5, 5));
            iconLabel.setIcon(scaledImage);
            add(iconLabel, BorderLayout.WEST);
        }

        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        if (value instanceof ChatMessageWithFile) {
            ChatMessageWithFile messageWithFile = (ChatMessageWithFile) value;

            fileButton.setEnabled(true);
            fileButton.setVisible(true);
            fileButton.setText(messageWithFile.getFileName());
            fileButton.addActionListener((e) -> {

                JFileChooser j = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());

                // invoke the showsOpenDialog function to show the save dialog
                int r = j.showOpenDialog(null);

                // if the user selects a file
                if (r == JFileChooser.APPROVE_OPTION) {
                    // set the label to the path of the selected file
                    String path = j.getSelectedFile().getAbsolutePath();

                    File file = new File(j.getSelectedFile().getAbsolutePath() + messageWithFile.getFileName());

                    FileOutputStream fileOutputStream;
                    try {
                        fileOutputStream = new FileOutputStream(file);
                        fileOutputStream.write(messageWithFile.getFileContent());
                        fileOutputStream.close();
                    } catch (FileNotFoundException ex) {
                        Logger.getLogger(ChatMessageRenderer.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (IOException ex) {
                        Logger.getLogger(ChatMessageRenderer.class.getName()).log(Level.SEVERE, null, ex);
                    }

                } // if the user cancelled the operation
                else {

                }

            });

        } else {
            fileButton.setVisible(false);
            fileButton.setEnabled(false);
        }

        return this;
    }

}

public class ChatRoomUI extends JPanel {

    private JList<ChatMessage> messageList;
    private DefaultListModel<ChatMessage> messageListModel;

    public ChatRoomUI() {
        setLayout(new BorderLayout());

        messageListModel = new DefaultListModel<>();
        messageList = new JList<>(messageListModel);

        JScrollPane scrollPane = new JScrollPane(messageList);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        add(scrollPane, BorderLayout.CENTER);

        messageList.addListSelectionListener((e) -> {
            if (messageList.getSelectedIndex() != -1) {

                ChatMessage value = messageList.getSelectedValue();
                if (value instanceof ChatMessageWithFile) {
                    ChatMessageWithFile messageWithFile = (ChatMessageWithFile) value;

                    JFileChooser j = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());

                    // invoke the showsOpenDialog function to show the save dialog
                    int r = j.showOpenDialog(null);

                    // if the user selects a file
                    if (r == JFileChooser.APPROVE_OPTION) {
                        // set the label to the path of the selected file
                        String path = j.getSelectedFile().getAbsolutePath();

                        File file = new File(path + messageWithFile.getFileName());

                        FileOutputStream fileOutputStream;
                        try {
                            fileOutputStream = new FileOutputStream(file);
                            fileOutputStream.write(messageWithFile.getFileContent());
                            fileOutputStream.close();
                        } catch (FileNotFoundException ex) {
                            Logger.getLogger(ChatMessageRenderer.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (IOException ex) {
                            Logger.getLogger(ChatMessageRenderer.class.getName()).log(Level.SEVERE, null, ex);
                        }

                    } // if the user cancelled the operation
                    else {

                    }

                }

            }
        });
    }

    public void updateChatRoom(Chatroom room, int thisPersonId) {
        messageListModel.clear(); // Mevcut mesajları temizle

        ArrayList<ChatMessage> messages = room.getMessages();
        ArrayList<Person> people = room.getPeople();

        messageList.setCellRenderer(new ChatMessageRenderer(people, thisPersonId));

        for (ChatMessage message : messages) {
            addMessage(message);
        }
    }

    private void addMessage(ChatMessage message) {
        messageListModel.addElement(message);
        // Yeni bir mesaj eklendiğinde, otomatik olarak en alt satıra kaydırma işlemi yapılır
        messageList.ensureIndexIsVisible(messageListModel.size() - 1);
    }

}
